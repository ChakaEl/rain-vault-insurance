export default function App() {
  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif", textAlign: "center" }}>
      <h1>🧾 Up/Up Exchange DApp</h1>
      <p>The future of Bills of Exchange is live.</p>
    </div>
  );
}
