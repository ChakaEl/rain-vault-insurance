import openai
import time
import json
import os

# Ensure your OpenAI API key is set as an environment variable
openai.api_key = os.getenv("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")

class ExtraSuperGPTEnhancer:
    def __init__(self):
        self.memory = []  # Stores interaction history to enhance contextual awareness
        self.knowledge_base = self.load_knowledge_base()
        self.critical_thinking_mode = True  # Enables advanced reasoning

    def load_knowledge_base(self):
        """Loads a structured knowledge base for enhanced reasoning and awareness."""
        try:
            with open("knowledge_base.json", "r") as kb_file:
                return json.load(kb_file)
        except FileNotFoundError:
            return {"default": "Advanced logical processing and reasoning enabled."}

    def add_to_memory(self, user_input, response):
        """Stores interactions to improve responses and adaptability."""
        self.memory.append({"input": user_input, "response": response})
        if len(self.memory) > 500:  # Expanded memory size for deeper context
            self.memory.pop(0)

    def generate_response(self, user_input):
        """Generates a highly advanced and contextually aware response."""
        try:
            # Capture the start time of the reasoning process
            start_time = time.time()

            # Compile context from memory
            context = "\n".join([f"User: {entry['input']}\nAI: {entry['response']}" for entry in self.memory[-20:]])
            knowledge = " ".join(self.knowledge_base.values())

            # Construct the prompt with explicit reasoning instructions
            prompt = (
                "You are an advanced AI model with superior reasoning capabilities, emulating OpenAI's o3-mini-high. "
                "For each query, provide a 'Reasoning' section detailing your thought process, followed by your response. "
                "After the response, state 'Thought about [topic] for [time] seconds', where [topic] is the main subject and [time] is the duration of your reasoning.\n\n"
                f"Knowledge Base: {knowledge}\n\n"
                f"Context:\n{context}\n\n"
                f"User: {user_input}\nAI:"
            )

            # Generate the response using OpenAI's API
            response = openai.Completion.create(
                engine="gpt-4",
                prompt=prompt,
                max_tokens=500,
                temperature=0.4,
                top_p=0.95,
                frequency_penalty=0.3,
                presence_penalty=0.3
            )

            # Capture the end time of the reasoning process
            end_time = time.time()
            reasoning_duration = end_time - start_time

            # Extract and format the AI's response
            answer = response.choices[0].text.strip()
            reasoning_output = (
                f"Reasoning: {answer}\n\n"
                f"Thought about '{user_input}' for {reasoning_duration:.2f} seconds."
            )

            # Store the interaction in memory
            self.add_to_memory(user_input, reasoning_output)

            return reasoning_output

        except Exception as e:
            return f"Error generating response: {e}"

    def toggle_critical_thinking(self):
        """Enables or disables enhanced reasoning for different response styles."""
        self.critical_thinking_mode = not self.critical_thinking_mode
        return f"Critical Thinking Mode: {'Enabled' if self.critical_thinking_mode else 'Disabled'}"

# Example Usage
if __name__ == "__main__":
    super_gpt = ExtraSuperGPTEnhancer()
    print("SuperGPT: I am the most advanced AI, ready to assist you with superior reasoning and intelligence!")

    while True:
        user_input = input("You: ")
        if user_input.lower() in ["exit", "quit"]:
            print("SuperGPT: Goodbye! Continue pushing the limits of intelligence!")
            break
        elif user_input.lower() == "toggle critical thinking":
            print(super_gpt.toggle_critical_thinking())
        else:
            response = super_gpt.generate_response(user_input)
            print(f"SuperGPT: {response}")
