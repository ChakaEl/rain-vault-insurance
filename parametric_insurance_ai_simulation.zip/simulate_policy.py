from super_bot import SuperGPTEnhancer
from extrasuper_bot import ExtraSuperGPTEnhancer

class PolicySimulation:
    def __init__(self, location, condition, duration_days, payout_amount):
        self.location = location
        self.condition = condition
        self.duration_days = duration_days
        self.payout_amount = payout_amount
        self.enhancer = SuperGPTEnhancer()
        self.optimizer = ExtraSuperGPTEnhancer()

    def run(self):
        context = (
            f"A user in {self.location} requests weather insurance for '{self.condition}' over "
            f"{self.duration_days} days. Estimate a fair premium for a payout of {self.payout_amount} USDC."
        )

        raw_response = self.enhancer.generate_response(context)
        refined_response = self.optimizer.optimize(raw_response)

        return {
            "location": self.location,
            "condition": self.condition,
            "duration": f"{self.duration_days} days",
            "payout": f"{self.payout_amount} USDC",
            "ai_raw_response": raw_response,
            "ai_optimized_response": refined_response
        }