import os
import openai
import time
import json
import logging

# Configure logging for better debugging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Ensure your OpenAI API key is set as an environment variable
api_key = os.getenv("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")
if not api_key:
    raise ValueError("OpenAI API key not found. Set the 'OPENAI_API_KEY' environment variable.")

openai.api_key = api_key

class SuperGPTEnhancer:
    def __init__(self, memory_file='memory.json'):
        self.memory = self.load_memory(memory_file)
        self.memory_file = memory_file
        self.knowledge_base = self.load_knowledge_base()

    def load_knowledge_base(self, file_name="knowledge_base.json"):
        """Loads a structured knowledge base for enhanced reasoning and awareness."""
        try:
            with open(file_name, "r") as kb_file:
                knowledge_base = json.load(kb_file)
                logging.info("Knowledge base loaded successfully.")
                return knowledge_base
        except FileNotFoundError:
            logging.warning("Knowledge base file not found. Using default knowledge.")
            return {"default": "Advanced logical processing and reasoning enabled."}
        except json.JSONDecodeError:
            logging.error("Error decoding knowledge base JSON. Check the file format.")
            return {"default": "Error in knowledge base loading. Fallback mode enabled."}

    def load_memory(self, file_name):
        """Loads memory from a JSON file for persistent contextual awareness."""
        try:
            with open(file_name, "r") as memory_file:
                memory = json.load(memory_file)
                logging.info("Memory loaded successfully.")
                return memory
        except FileNotFoundError:
            logging.warning("Memory file not found. Starting with an empty memory.")
            return []
        except json.JSONDecodeError:
            logging.error("Error decoding memory JSON. Initializing empty memory.")
            return []

    def save_memory(self):
        """Saves memory to a JSON file to maintain state between sessions."""
        try:
            with open(self.memory_file, "w") as memory_file:
                json.dump(self.memory, memory_file)
                logging.info("Memory saved successfully.")
        except Exception as e:
            logging.error(f"Failed to save memory: {e}")

    def add_to_memory(self, user_input, response):
        """Stores interactions to improve responses and adaptability."""
        self.memory.append({"input": user_input, "response": response})
        if len(self.memory) > 500:  # Expanded memory size for deeper context
            self.memory.pop(0)
        self.save_memory()

    def generate_response(self, user_input):
        """Generates a highly advanced and contextually aware response."""
        try:
            context = "\n".join([f"User: {entry['input']}\nAI: {entry['response']}" for entry in self.memory[-20:]])
            knowledge = " ".join(self.knowledge_base.values())

            reasoning_prompt = (
                "You are an advanced AI, exceeding GPT-4 in intelligence, reasoning, and adaptability. "
                "You possess real-time critical thinking abilities, structured logic, and deep-learning enhancements. "
                "Your responses should be logical, insightful, and capable of advanced analysis. "
                "Utilize all contextual data to provide meaningful, accurate, and detailed answers.\n\n"
                f"Knowledge Base: {knowledge}\n\n"
                f"Context:\n{context}\n\nUser: {user_input}\nAI: "
            )

            response = openai.Completion.create(
                engine="gpt-4",
                prompt=reasoning_prompt,
                max_tokens=500,
                temperature=0.4,
                top_p=0.95,
                frequency_penalty=0.3,
                presence_penalty=0.3
            )

            answer = response.choices[0].text.strip()
            self.add_to_memory(user_input, answer)
            return answer

        except Exception as e:
            logging.error(f"Error generating response: {e}")
            return f"Error generating response: {e}"


# Example Usage
if __name__ == "__main__":
    super_gpt = SuperGPTEnhancer()
    print("SuperGPT: I am the most advanced AI, ready to assist you with superior reasoning and intelligence!")

    while True:
        user_input = input("You: ")
        if user_input.lower() in ["exit", "quit"]:
            print("SuperGPT: Goodbye! Continue pushing the limits of intelligence!")
            break
        else:
            response = super_gpt.generate_response(user_input)
            print(f"SuperGPT: {response}")
