from supreme_intelligence import SupremeIntelligence

class DAOPolicyDebate:
    def __init__(self, policy_details):
        self.policy_details = policy_details
        self.governance_ai = SupremeIntelligence()

    def debate_policy(self):
        prompt = f"""
        As a decentralized DAO governance AI with critics, optimizers, and pragmatists,
        evaluate the following insurance policy proposal:

        - Location: {self.policy_details['location']}
        - Condition: {self.policy_details['condition']}
        - Duration: {self.policy_details['duration']}
        - Payout: {self.policy_details['payout']}
        - Premium: {self.policy_details.get('suggested_premium', 'TBD')}

        Determine whether this policy should be approved based on risk, cost-efficiency,
        pool sustainability, and historical feasibility.

        Output:
        - DAO Vote Result (APPROVE/REJECT)
        - Key Points from Each Agent
        - Final Governance Decision Summary
        """
        result = self.governance_ai.generate_response(prompt)
        return result