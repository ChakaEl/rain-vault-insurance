from simulate_policy import PolicySimulation
from dao_policy_voting import DAOPolicyDebate

users = [
    {"location": "Bordeaux", "condition": "hail>2cm", "duration_days": 30, "payout_amount": 100},
    {"location": "Nairobi", "condition": "drought>10 days", "duration_days": 45, "payout_amount": 80},
    {"location": "Miami", "condition": "flood>10cm", "duration_days": 20, "payout_amount": 120},
    {"location": "Delhi", "condition": "heatwave>45C", "duration_days": 15, "payout_amount": 90},
    {"location": "Jakarta", "condition": "rainfall>300mm", "duration_days": 25, "payout_amount": 70}
]

results = []

for user in users:
    simulation = PolicySimulation(**user)
    quote = simulation.run()

    policy_input = {
        "location": quote["location"],
        "condition": quote["condition"],
        "duration": quote["duration"],
        "payout": quote["payout"],
        "suggested_premium": quote["ai_optimized_response"].get("suggested_premium", "TBD")
    }

    debate = DAOPolicyDebate(policy_input)
    governance_result = debate.debate_policy()

    results.append({
        "quote": quote,
        "governance_result": governance_result
    })

import json
with open("insurance_simulation_results.json", "w") as f:
    json.dump(results, f, indent=2)

print("Simulation complete. Results saved to 'insurance_simulation_results.json'")